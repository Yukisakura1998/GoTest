package znet

import (
	"fmt"
	"net"
	"zinx/zinx/utils"
	"zinx/zinx/ziface"
)

type Server struct {
	IPVersion string
	IPAddress string
	Port      int
	Name      string
	conn      net.Conn
	//Router         ziface.IRouter
	MessageHandler ziface.IMassageHandle
}

//// CallBackHandleFunc 定义一个API，后改自定义
//func CallBackHandleFunc(conn *net.TCPConn, data []byte, length int) error {
//	fmt.Println("[Connection HandelFunc callback] ")
//	if _, err := conn.Write(data[:length]); err != nil {
//		fmt.Println("callback error")
//		return errors.New("CallBack error")
//	}
//	return nil
//}

func (s *Server) Start() {
	fmt.Println("Server is starting!")

	go func() {
		s.MessageHandler.StartWorkerPool()

		addr, err := net.ResolveTCPAddr(s.IPVersion, fmt.Sprintf("%s:%d", s.IPAddress, s.Port))
		if err != nil {
			return
		}

		listener, err := net.ListenTCP(s.IPVersion, addr)
		if err != nil {
			fmt.Println("listen", s.IPVersion, "err", err)
			return
		}

		fmt.Println("start Zinx server ", addr, " success, now listening...")

		var cid uint32
		cid = 0
		//阻塞
		for {
			conn, err := listener.AcceptTCP()
			if err != nil {
				fmt.Println("Accept err ", err)
				continue
			}

			//主要的入口
			delConn := NewConnection(conn, cid, s.MessageHandler)
			cid++
			go delConn.Start()

		}
	}()
}

func (s *Server) Stop() {
	fmt.Println("[STOP] Zinx server , name ", s.Name)
}

func (s *Server) Server() {
	s.Start()
	select {}
}
func (s *Server) AddRouter(msgId uint32, router ziface.IRouter) {
	s.MessageHandler.AddRouter(msgId, router)
	fmt.Println("[ADD] Zinx router , name ", s.Name, " success, id ", msgId)
}
func NewServer() ziface.IServer {
	utils.GlobalObject.LoadJson()
	s := &Server{
		IPVersion:      "tcp4",
		IPAddress:      utils.GlobalObject.Host,
		Port:           utils.GlobalObject.TcpPort,
		Name:           utils.GlobalObject.Name,
		MessageHandler: NewMessageHandler(),
	}
	return s
}
